var family = [{
        name: 'parinaz',
        last_name: 'Ebrahimi',
        favorite_color: 'black',
        age: 21,
        weight: 50
    },
    {
        name: 'parisa',
        maried: false,
        favorite_food: "soap"
    }
]

console.log(family);