var family_persons = ["parinaz", "setayesh", "roya"];
var nameric = [21, 18, 19];
console.log(family_persons);
console.log(nameric);